# Guion sugerido para video explicativo (2–3 minutos)

**Importante:** todos los integrantes deben participar en el video. Mostrar únicamente funciones que hayan probado. Sustituir corchetes por datos reales del equipo.

| Tiempo | Participante | Contenido |
|---|---|---|
| 0:00–0:20 | [Integrante 1] | “Somos el equipo [nombre] y presentamos el inicio del desarrollo del juego Dardos 301 en Python.” |
| 0:20–0:45 | [Integrante 2] | Explicar los módulos: `juego.py` para el modo local, `game_logic.py` para reglas y `server.py`/`client.py` para el modo LAN. |
| 0:45–1:20 | [Integrante 3] | Demostrar una partida local: entrada de puntos, marcador y cambio de turno. |
| 1:20–1:55 | [Integrante 4] | Si ya se probó en dos equipos, mostrar conexión cliente-servidor y sincronización. Si aún no, describirla como implementación inicial y no como prueba completada. |
| 1:55–2:20 | [Integrante 5 o rotación] | Mencionar TCP, mensajes JSON delimitados por salto de línea, validación del servidor y licencia MIT. |
| 2:20–2:45 | Todos / cierre | Resumir lo logrado, las pruebas pendientes y el repositorio: [URL real cuando exista]. |

## Capturas recomendadas

1. Árbol del proyecto en el editor.
2. Ejecución del modo local.
3. Dos terminales, servidor y cliente, solo después de probarlos en una LAN real.
4. README con atribución, licencia y créditos.
